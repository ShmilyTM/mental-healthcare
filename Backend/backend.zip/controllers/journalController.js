const Journal = require("../models/Journal");
const EmotionStat = require("../models/EmotionStat");
const axios = require("axios");

// 🧘 Viết nhật ký cảm xúc
exports.createJournal = async (req, res) => {
  try {
    const { title, content } = req.body;

    // 🧠 Phân tích cảm xúc bằng AI
    const aiRes = await axios.post(
      "https://api.openai.com/v1/chat/completions",
      {
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "Bạn là AI phân tích cảm xúc tiếng Việt." },
          {
            role: "user",
            content: `Phân tích cảm xúc đoạn sau: "${content}". Trả về JSON {"emotion": "...", "sentimentScore": ...}`,
          },
        ],
      },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        },
      }
    );

    // 🧩 Giải mã kết quả AI
    let emotion = "bình yên";
    let sentimentScore = 0;
    try {
      const parsed = JSON.parse(aiRes.data.choices[0].message.content);
      emotion = parsed.emotion || "bình yên";
      sentimentScore = parsed.sentimentScore || 0;
    } catch {
      emotion = "bình yên";
    }

    // 💾 Lưu journal
    const journal = new Journal({
      user: req.user.id,
      title,
      content,
      emotion,
      sentimentScore,
    });
    await journal.save();

    // 📊 Cập nhật thống kê cảm xúc theo ngày
    const date = new Date().toISOString().split("T")[0];
    let stat = await EmotionStat.findOne({ user: req.user.id, date });
    if (!stat) stat = new EmotionStat({ user: req.user.id, date });
    stat.emotionCounts[emotion] = (stat.emotionCounts[emotion] || 0) + 1;
    await stat.save();

    res.status(201).json({ message: "Đã lưu nhật ký cảm xúc", journal });
  } catch (err) {
    console.error("❌ Lỗi khi tạo nhật ký:", err);
    res.status(500).json({ message: err.message });
  }
};

// 📅 Xem danh sách nhật ký của người dùng
exports.getMyJournals = async (req, res) => {
  try {
    const journals = await Journal.find({ user: req.user.id }).sort({ createdAt: -1 });
    res.json(journals);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// 📊 Xem thống kê cảm xúc
exports.getEmotionStats = async (req, res) => {
  try {
    const stats = await EmotionStat.find({ user: req.user.id }).sort({ date: 1 });
    res.json(stats);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ❌ Xóa nhật ký cảm xúc
exports.deleteJournal = async (req, res) => {
  try {
    const journal = await Journal.findOne({ _id: req.params.id, user: req.user.id });
    if (!journal) return res.status(404).json({ message: "Không tìm thấy nhật ký" });

    await Journal.deleteOne({ _id: journal._id });
    res.json({ message: "Đã xóa nhật ký thành công" });
  } catch (err) {
    console.error("❌ Lỗi khi xóa nhật ký:", err);
    res.status(500).json({ message: "Lỗi khi xóa nhật ký" });
  }
};

// 👩‍⚕️ [GET] /api/journals/patient/:patientId
// 👉 Dành cho bác sĩ: xem nhật ký cảm xúc của bệnh nhân
exports.getPatientJournals = async (req, res) => {
  try {
    const { patientId } = req.params;
    const journals = await Journal.find({ user: patientId })
      .sort({ createdAt: -1 })
      .select("title content emotion sentimentScore createdAt");

    if (!journals.length)
      return res.status(404).json({ message: "Bệnh nhân này chưa ghi nhật ký nào" });

    res.json(journals);
  } catch (err) {
    console.error("❌ Lỗi khi lấy nhật ký bệnh nhân:", err);
    res.status(500).json({ message: "Lỗi khi tải nhật ký bệnh nhân" });
  }
};

// 📬 Gửi bài tập / lời khuyên cho bệnh nhân
exports.sendRecommendation = async (req, res) => {
  try {
    const { patientId, advice } = req.body;
    // TODO: tích hợp email hoặc notification sau
    res.json({
      message: "Đã gửi bài tập / lời khuyên đến bệnh nhân",
      patientId,
      advice,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

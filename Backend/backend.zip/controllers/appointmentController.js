const Appointment = require("../models/Appointment");

// [POST] Tạo lịch hẹn
exports.createAppointment = async (req, res) => {
  try {
    const { targetId, type, date, time, mode, note } = req.body;

    const appointment = new Appointment({
      customer: req.user.id,
      expert: targetId,
      expertType: type === "doctor" ? "Doctor" : "Healer",
      date,
      time,
      mode,
      note,
    });

    await appointment.save();
    res.status(201).json({ message: "Đã tạo lịch hẹn thành công", appointment });
  } catch (err) {
    console.error("❌ Appointment error:", err);
    res.status(500).json({ message: "Lỗi khi tạo lịch hẹn" });
  }
};

// [GET] Lấy lịch hẹn của người dùng
exports.getMyAppointments = async (req, res) => {
  try {
    const appointments = await Appointment.find({ customer: req.user.id })
      .populate("expert", "name specialization")
      .sort({ date: -1 });
    res.json(appointments);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// [DELETE] Hủy lịch hẹn
exports.cancelAppointment = async (req, res) => {
  try {
    const appointment = await Appointment.findOne({
      _id: req.params.id,
      customer: req.user.id,
    });
    if (!appointment)
      return res.status(404).json({ message: "Không tìm thấy lịch hẹn" });

    await Appointment.deleteOne({ _id: appointment._id });
    res.json({ message: "Đã hủy lịch hẹn" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// [GET] 👑 Admin xem tất cả lịch hẹn
exports.getAllAppointments = async (req, res) => {
  try {
    const { status, dateFrom, dateTo } = req.query;
    const filter = {};

    if (status) filter.status = status;
    if (dateFrom || dateTo) {
      filter.date = {};
      if (dateFrom) filter.date.$gte = new Date(dateFrom);
      if (dateTo) filter.date.$lte = new Date(dateTo);
    }

    const appointments = await Appointment.find(filter)
      .populate("customer", "name email")
      .populate("expert", "name specialization")
      .sort({ date: -1 });

    res.json(appointments);
  } catch (err) {
    console.error("❌ Lỗi khi lấy danh sách lịch hẹn:", err);
    res.status(500).json({ message: "Lỗi lấy danh sách lịch hẹn" });
  }
};


// [PATCH] 👑 Admin duyệt / từ chối lịch hẹn
exports.updateAppointmentStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const appointment = await Appointment.findById(id);
    if (!appointment)
      return res.status(404).json({ message: "Không tìm thấy lịch hẹn" });

    appointment.status = status;
    await appointment.save();

    res.json({ message: `Đã cập nhật trạng thái thành ${status}`, appointment });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

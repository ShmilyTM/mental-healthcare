const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const {
  createJournal,
  getMyJournals,
  deleteJournal,
  getPatientJournals, // 👈 thêm vào đây
} = require("../controllers/journalController");

// ✍️ Bệnh nhân viết nhật ký
router.post("/", protect, createJournal);

// 📖 Xem nhật ký của chính mình
router.get("/me", protect, getMyJournals);

// ❌ Xóa nhật ký
router.delete("/:id", protect, deleteJournal);

// 👩‍⚕️ Bác sĩ xem nhật ký bệnh nhân
router.get("/patient/:patientId", protect, getPatientJournals);

module.exports = router;

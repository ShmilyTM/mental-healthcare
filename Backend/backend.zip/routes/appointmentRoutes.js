const express = require("express");
const router = express.Router();
const { protect, adminOnly } = require("../middleware/authMiddleware");
const {
  createAppointment,
  getMyAppointments,
  cancelAppointment,
  getAllAppointments,
  updateAppointmentStatus,
} = require("../controllers/appointmentController");

// 👩‍🦰 Customer routes
router.post("/", protect, createAppointment);          // Tạo lịch hẹn
router.get("/me", protect, getMyAppointments);         // Xem lịch hẹn của chính mình
router.delete("/:id", protect, cancelAppointment);     // Hủy lịch hẹn

// 👨‍💼 Admin routes
router.get("/", protect, adminOnly, getAllAppointments);               // Xem tất cả lịch hẹn
router.patch("/:id/status", protect, adminOnly, updateAppointmentStatus); // Cập nhật trạng thái (duyệt / từ chối)

module.exports = router;
